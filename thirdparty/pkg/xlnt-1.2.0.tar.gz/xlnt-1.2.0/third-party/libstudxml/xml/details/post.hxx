// file      : xml/details/post.hxx
// copyright : Copyright (c) 2013-2017 Code Synthesis Tools CC
// license   : MIT; see accompanying LICENSE file

#ifdef _MSC_VER
#  pragma warning (pop)
#endif
