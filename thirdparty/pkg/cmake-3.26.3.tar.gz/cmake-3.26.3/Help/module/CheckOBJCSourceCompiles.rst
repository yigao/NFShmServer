.. cmake-module:: ../../Modules/CheckOBJCSourceCompiles.cmake
